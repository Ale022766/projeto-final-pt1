#!/usr/bin/python3

# Copyright Contributors to the Packit project.
# SPDX-License-Identifier: MIT

from setuptools import setup

setup(use_scm_version=True)
