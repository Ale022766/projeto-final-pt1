For details about build configuration please check [deployment documentation](https://github.com/packit/deployment#image-build-process)
