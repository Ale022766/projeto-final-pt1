# Copyright Contributors to the Packit project.
# SPDX-License-Identifier: MIT


class ValidationFailed(Exception):
    pass
