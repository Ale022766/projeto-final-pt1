# Copyright Contributors to the Packit project.
# SPDX-License-Identifier: MIT

import logging

from packit_service.constants import (
    KOJI_PRODUCTION_BUILDS_ISSUE,
    PERMISSIONS_ERROR_WRITE_OR_ADMIN,
)
from packit_service.models import SidetagModel
from packit_service.worker.checker.abstract import Checker
from packit_service.worker.events import (
    MergeRequestGitlabEvent,
    PullRequestGithubEvent,
)
from packit_service.worker.events.enums import GitlabEventAction
from packit_service.worker.handlers.mixin import GetKojiBuildJobHelperMixin
from packit_service.worker.reporting import BaseCommitStatus

logger = logging.getLogger(__name__)


class IsJobConfigTriggerMatching(Checker, GetKojiBuildJobHelperMixin):
    def pre_check(self) -> bool:
        return self.koji_build_helper.is_job_config_trigger_matching(self.job_config)


class PermissionOnKoji(Checker, GetKojiBuildJobHelperMixin):
    def pre_check(self) -> bool:
        if (
            self.data.event_type == MergeRequestGitlabEvent.__name__
            and self.data.event_dict["action"] == GitlabEventAction.closed.value
        ):
            # Not interested in closed merge requests
            return False

        if self.data.event_type in (
            PullRequestGithubEvent.__name__,
            MergeRequestGitlabEvent.__name__,
        ):
            user_can_merge_pr = self.project.can_merge_pr(self.data.actor)
            if not (user_can_merge_pr or self.data.actor in self.service_config.admins):
                self.koji_build_helper.report_status_to_all(
                    description=PERMISSIONS_ERROR_WRITE_OR_ADMIN,
                    state=BaseCommitStatus.neutral,
                )
                return False

        if not self.koji_build_helper.is_scratch:
            msg = "Non-scratch builds not possible from upstream."
            self.koji_build_helper.report_status_to_all(
                description=msg,
                state=BaseCommitStatus.neutral,
                url=KOJI_PRODUCTION_BUILDS_ISSUE,
            )
            return False

        return True


class SidetagExists(Checker):
    def pre_check(self) -> bool:
        return SidetagModel.get_by_koji_name(self.data.tag_name) is not None
