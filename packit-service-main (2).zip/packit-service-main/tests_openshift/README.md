How to run and regenerate tests see instructions in [CONTRIBUTING guide](/CONTRIBUTING.md#openshift-tests-using-requre)
